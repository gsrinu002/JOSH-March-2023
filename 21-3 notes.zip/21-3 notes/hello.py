print
print(2+3)
name ='python'
print(name * 4)
a,b,c=10,20,30
print(a)
print(type(a))
print(type(name))

my_name=input('enter ur name')
print('my name is',my_name)